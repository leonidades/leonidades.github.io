<?php
require_once "../model/AccesoBD.class.php";
$token=$_POST["token"];
$correo=$_POST["correo"];
$pass=$_POST["pass"];

if ($token==AccesoBD::getInstance()->sacarTokenDeUsuario($correo)) {
    AccesoBD::getInstance()->cambiarPass($correo,$pass);
    header('Location: /kalpataru/index.php');
}else{
    echo "nop";
}

?>