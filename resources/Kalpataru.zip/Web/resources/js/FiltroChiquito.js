function MostrarFiltro(){
if(document.getElementById("filtro").style.display==="none"){
document.getElementById("filtro").style.display="block";
document.getElementById("filtro").style.position="fixed";
}else{
document.getElementById("filtro").style.display="none";
}

}

function OcultarFiltro(){
    if(screen.width < 600){
        document.getElementById("filtro").style.display="none";
    }

}