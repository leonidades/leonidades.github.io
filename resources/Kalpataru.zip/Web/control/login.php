<?php
require "../model/AccesoBD.class.php";

$usuario=AccesoBD::getInstance()->getUsuario($_POST['pwd'],$_POST['correo']);


if (isset($usuario)) {
    session_start();
    $_SESSION['usuario']=serialize($usuario);
    header('Location: /kalpataru/index.php?view=miperfil');
}else{
    header('Location: /kalpataru/index.php?view=iniciarSesion&error=1');
}
?>
