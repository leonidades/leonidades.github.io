<?php
require_once "usuario.class.php";
require_once "deseos.class.php";
class AccesoBD{
    const RUTA="localhost";
    const NOMBRE_BD="kalpatarubd";
    const USER="root";
    const PASS="z";
    public $conexion;
    private static $bd;
    function __construct(){
        
        $this->establecerConexion();
    }
    function establecerConexion(){
    $this->conexion=mysqli_connect(self::RUTA,self::USER,self::PASS,self::NOMBRE_BD) or die("no base de datos");
    
    }
    function lanzarSQL($sql){

        $tipoSQL=substr($sql,0,6);
        $result=mysqli_query($this->conexion,$sql);

        if (strtoupper($tipoSQL)=="SELECT") {
            return $result;
        }
    }

    public static function getInstance(){

        if (!isset(self::$bd)) {
            self::$bd= new static();
        }

        return self::$bd;
    }

    function CrearDeseo($texto,$usuario,$idioma){
        //Necesitamos Capturar la fecha correctamente
        $date=date('Y-m-d');
        $this->lanzarSQL("INSERT INTO `deseos` (`texto`, `fecha_enviado`,`correo`, `idioma`) VALUES ('$texto','$date','$usuario->correo',$idioma);");
        $cap_id=$this->lanzarSQL("SELECT id from deseos where id=(Select max(id) from deseos);");
        while($fila_id=mysqli_fetch_array($cap_id)){
            $id=$fila_id["id"];
        }
        return $id;
        // $correo=$usuario->correo;
        // echo "$texto : $correo : $idioma : $date";
        // $sql= $this->conexion->prepare("INSERT INTO `deseos` (`texto`, `fecha_enviado`,`correo`, `idioma`) VALUES (?,'$date','$correo',?);");
        // $sql->bind_param("si",$texto,$idioma);
        // $sql->excute();
        // $sql->close();
    }

    function CapturarDeseoConcreto($id){
        
        $cap_deseo=$this->lanzarSQL("SELECT * FROM deseos WHERE id=$id;");
        while($fila_deseo=mysqli_fetch_array($cap_deseo)){
            $cap_usuario=$this->lanzarSQL("SELECT * FROM usuarios where correo='".$fila_deseo["correo"]."';");
            while($fila_usuario=mysqli_fetch_array($cap_usuario)){
                $creador=new Usuario($fila_usuario["DNI"],$fila_usuario["Correo"],$fila_usuario["Nombre"],$fila_usuario["Primer_Apellido"],$fila_usuario["Segundo_Apellido"],$fila_usuario["Curso"],$fila_usuario["administrador"]);
            }
            $deseo=new Deseo($fila_deseo["id"],$fila_deseo["texto"],$fila_deseo["fecha_enviado"],$fila_deseo["idioma"],$creador,0);
        }
        return $deseo;
    }
    function SacarValoracionesDeDeseo($idDeseo){
        
            $cap_valoraciones=$this->lanzarSQL("SELECT COUNT(\"id\") as \"valoraciones\" FROM valoracion where id=\"$idDeseo\"");
            while($fila_valoracion=mysqli_fetch_array($cap_valoraciones)){
            return $fila_valoracion["valoraciones"];
            }
    }

    //no se si funciona
    function MostrarDeseosQueMeGustan($usuario){
        $deseos=array();
        $cap_id=$this->lanzarSQL("SELECT `id` FROM `valoracion` WHERE correo='$usuario->correo'");
        while (($filaid=mysqli_fetch_array($cap_id))){
            $id_deseo=$filaid["id"];
            $capDeseos=$this->lanzarSQL("SELECT * FROM `deseos` WHERE id=\"$id_deseo\"");
            while ($fila_deseo=mysqli_fetch_array($capDeseos)) {
                $correo_deseo=$fila_deseo["correo"];
                $texto_deseo=$fila_deseo["texto"];
                $fecha_deseo=$fila_deseo["fecha_enviado"];
                $idioma_deseo=$fila_deseo["idioma"];

                $capCreador=$this->lanzarSQL("SELECT * FROM `usuarios` WHERE correo=\"$correo_deseo\"");
                while ($fila_creador=mysqli_fetch_array($capCreador)) {
                $nombre_creador=$fila_creador["Nombre"];
                $correo=$fila_creador["Correo"];
                $Primer_apellido=$fila_creador["Primer_Apellido"];
                $Segundo_apellido=$fila_creador["Segundo_Apellido"];
                $dni_creador=$fila_creador["DNI"];
                $curso_creador=$fila_creador["Curso"];
                $adminstrador_creador=$fila_creador["administrador"];

                    $creador=new Usuario($dni_creador,$correo,$nombre_creador,$Primer_apellido,$Segundo_apellido,$curso_creador,$adminstrador_creador);
                }
                
                $deseos[]=new Deseo($id_deseo,$texto_deseo, $fecha_deseo,$idioma_deseo,$creador,0);
            }
            
        }
        return $deseos;
    }
    function MostrarMisDeseos($usuario){
        $deseos=array();
        $cap_deseos=$this->lanzarSQL("SELECT * FROM `deseos` WHERE correo=\"$usuario->correo\";");
        while ($fila_deseo=mysqli_fetch_array($cap_deseos)) {
        
        $deseos[]=$deseo=new Deseo($fila_deseo["id"],$fila_deseo["texto"],$fila_deseo["fecha_enviado"],$fila_deseo["idioma"],$usuario, 0);

          
            
        }
        return $deseos;
    }

    function valorarDeseo($usuario, $id){
        $this->lanzarSQL("INSERT INTO valoracion (correo, id) VALUES (\"$usuario->correo\",\"$id\");");
    }

    function CancelarValorarDeseo($usuario, $id){
        $this->lanzarSQL("DELETE FROM valoracion WHERE correo=\"$usuario->correo\" AND id=\"$id\";");
    }
    function comprobrobarValoracionDeseo($usuario, $id_deseo){
        $cap_valoracion=$this->lanzarSQL("SELECT * FROM valoracion where correo=\"$usuario->correo\" AND id=$id_deseo;");
        $existe=false;
        while($fila_valoracion=mysqli_fetch_array($cap_valoracion)){
          $id=$fila_valoracion["id"];
        }
        if (isset($id)) {
            $existe=true;
        }
        return $existe;
    }

    function getUsuario($dni,$correo){

        // $sql= $this->conexion->prepare("SELECT * FROM usuarios where dni=\"$dni\" and correo=\"$correo\";");
        // $sql->excute();
        // $sql->bind_result("*");
        // $resultado =$sql->get_result();
        // $cap_usuario=$resultado->fetch_all(MYSQLI_ASSOC);

        // while($sql->fetch()){
        //     $usuario=new Usuario($dni,$correo,$nombre,$Primer_Apellido,$Segundo_Apellido,$Curso);
        // }
        $cap_usuario=$this->lanzarSQL("SELECT * FROM usuarios where dni=\"$dni\" and correo=\"$correo\";");
        while($fila_usuario=mysqli_fetch_array($cap_usuario)){

             $usuario=new Usuario($fila_usuario["DNI"],$fila_usuario["Correo"],$fila_usuario["Nombre"],$fila_usuario["Primer_Apellido"],$fila_usuario["Segundo_Apellido"],$fila_usuario["Curso"],$fila_usuario["administrador"]);
        }
        return $usuario;
    } 

    function NuevoTokenCambioDePass($token,$usuario){
        $this->lanzarSQL("UPDATE usuarios SET tokenCambiarPass=\"$token\" WHERE correo=\"$usuario->correo\";");
    }
    function cambiarPass($correo, $pass){
        $this->lanzarSQL("UPDATE usuarios SET tokenCambiarPass=null, dni=\"$pass\" WHERE correo=\"$correo\";");
    }
    function sacarTokenDeUsuario($correo){
        $cap_token=$this->lanzarSQL("SELECT tokenCambiarPass FROM usuarios where correo=\"$correo\";");

        while($fila_token=mysqli_fetch_array($cap_token)){

             $token=$fila_token["tokenCambiarPass"];
        }
        return $token;
    }

    function mostrarTodosLosDeseosNoValidados(){

        $cap_Deseo=$this->lanzarSQL("SELECT * FROM Deseos WHERE validado=0;");
        
        while($fila_deseo=mysqli_fetch_array($cap_Deseo)){
            $cap_usuario=$this->lanzarSQL("SELECT * FROM usuarios where correo='".$fila_deseo["correo"]."';");
                while($fila_usuario=mysqli_fetch_array($cap_usuario)){
                    $creador=new Usuario($fila_usuario["DNI"],$fila_usuario["Correo"],$fila_usuario["Nombre"],$fila_usuario["Primer_Apellido"],$fila_usuario["Segundo_Apellido"],$fila_usuario["Curso"],$fila_usuario["administrador"]);
                }
            $deseos[]=new Deseo($fila_deseo["id"],$fila_deseo["texto"],$fila_deseo["fecha_enviado"],$fila_deseo["idioma"],$creador,0);
            
        }
        return $deseos;
    }

    function ValidarDeseo($id_deseo){
        $this->lanzarSQL("UPDATE deseos SET validado=1 WHERE id=$id_deseo");
    }

    function RechazarDeseo($id_deseo){
        $this->lanzarSQL("UPDATE deseos SET validado=27 WHERE id=$id_deseo");
    }


    function mostrarDeseos($orden,$curso,$idioma){
       
        $NoPonerMasWhere=true;

        $sql="SELECT deseos.*, COUNT(valoracion.id) AS numero_valoraciones FROM deseos LEFT JOIN valoracion ON deseos.id = valoracion.id ";

        if ($curso!="all") {
            $sql=$sql." where deseos.correo IN (SELECT correo FROM usuarios where curso=\"$curso\")";
            if ($idioma=="castellano") {
            $sql=$sql." AND idioma=0";
            }else if($idioma=="euskera"){
            $sql=$sql." AND idioma=1";
            }
            $NoPonerMasWhere=false;
        } 

       
        if ($idioma!="all") {
            if ($NoPonerMasWhere==true) {
            if ($idioma=="castellano") {
                $sql=$sql." where idioma=0"; 
            }else {
                $sql=$sql." where idioma=1"; 
            }
            $NoPonerMasWhere=false;   
        }
       }

       if ($NoPonerMasWhere==true) {
        $sql=$sql." WHERE validado=1";
        $NoPonerMasWhere=false;   
        }else{
            $sql=$sql." AND validado=1";
        }

       $sql=$sql." GROUP BY deseos.id";

        if($orden!="random"){
            if ($orden=="antiguos") {
                $sql=$sql." ORDER BY fecha_enviado asc";
            }else if ($orden=="recientes"){
                $sql=$sql." ORDER BY fecha_enviado desc";
            }else if ($orden=="valorados"){
                $sql=$sql." ORDER BY numero_valoraciones DESC";
            }
        }
        $sql=$sql." LIMIT 50;";

            $cap_deseos=$this->lanzarSQL($sql);
           $deseos=array();
            while($fila_deseo=mysqli_fetch_array($cap_deseos)){
                $cap_usuario=$this->lanzarSQL("SELECT * FROM usuarios where correo='".$fila_deseo["correo"]."';");
                while($fila_usuario=mysqli_fetch_array($cap_usuario)){
                    $creador=new Usuario($fila_usuario["DNI"],$fila_usuario["Correo"],$fila_usuario["Nombre"],$fila_usuario["Primer_Apellido"],$fila_usuario["Segundo_Apellido"],$fila_usuario["Curso"],$fila_usuario["administrador"]);
                }
                $deseos[]=new Deseo($fila_deseo["id"],$fila_deseo["texto"],$fila_deseo["fecha_enviado"],$fila_deseo["idioma"],$creador, $fila_deseo["numero_valoraciones"]);
            }
           

        if ($orden=="random") {
                shuffle($deseos);
            }
            return $deseos;

    }
}

?>

