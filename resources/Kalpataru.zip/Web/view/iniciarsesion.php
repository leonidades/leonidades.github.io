    <main>
        <section id="principal">
            <div id="titulo">
                <h1> Inicio <span class="color">Sesion</span> </h1>
            </div>
            <form class="login-estilos" action="control/login.php" method="POST">
                <label id="nombre">
                    <span>Correo</span><input type="email" name="correo" placeholder="Escribe tu E-mail" required="true" />
                </label>
                <label id="passwd">
                    <span>Contraseña</span><input type="password" name="pwd" placeholder="Escribe tu DNI" required="true" />
                </label>
                    <button type="submit" class="btn">Iniciar Sesion</button>
                </div>
            </form>
            <?php
             if (isset($_GET["error"])) { 
                if ($_GET["error"]==1) {
                echo"<p>Usuario o contraseña no coinciden: Recuerda que debes ser alumno del centro San Luis para iniciar sesion</p>";
                }
            }
            ?>
        </section>
    </main>