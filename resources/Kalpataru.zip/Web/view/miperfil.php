<script src="./resources/js/miperfil.js"></script>
<main>
  <div id="lista">
    <ul>
      <li><a href="#" id="Datos">Mis Datos</a></li>
      <li><a href="#" id="Deseos">Mis Deseos</a></li>
      <li><a href="#" id="like">Me Gusta</a></li>
    </ul>
  </div>
<div id="MisDatos">
<form class="cambiopwd" action="control/EnviarCorreoCambioDePass.php" method="POST">
<h3>
  Hola <?php echo $usuario->nombre?>, estos son tus datos:
</h3>
<div id="caja">
  <p>Nombre:
    <?php echo $usuario->nombre?>
  </p>
  <p>Apellidos:
    <?php echo $usuario->primer_apellido?> <?php echo $usuario->segundo_apellido?>
  </p>
  <p>Correo:
    <?php echo $usuario->correo?>
  </p>
  <p>Contraseña: 
    <input type='password' id="pwd" name="pass" minlength="4" placeholder='Nueva contraseña' required>
  </p>
  <input type="submit" id="guardar" value="Cambiar contraseña">
  <?php
  if (isset($_GET["resultado"])) {
    if ($_GET["resultado"]==1) {
      echo"<p>Comprueba tu correo electronico</p>";
    }
  }
  ?>
</div>
</form>
<div id="CerrarSesion">
<form action="control/CerrarSesion.php" method="get">
<input type="submit" id="btncerrar" value="">
</form>
</div>
</div>
<div  id="MisDeseos">
  <div id="caja2">
  <?php
    $deseos=AccesoBD::getInstance()->MostrarMisDeseos($usuario);
    for ($i=0; $i < count($deseos) ; $i++) { 
      echo "<div class=\"estilodeseo\"><p>".$deseos[$i]->texto."</p></div>";
    }
    ?>
  </div>
</div>
<div id="MeGusta">
<div id="caja2">
    <?php
        $deseos=AccesoBD::getInstance()->MostrarDeseosQueMeGustan($usuario);
    for ($i=0; $i < count($deseos) ; $i++) { 
      echo "<div class=\"estilodeseo\"><p>".$deseos[$i]->texto."</p></div>";
    }
    ?>
  </div>
</div>
</main>
