-- Base de datos: `kalpataru`s
CREATE DATABASE kalpatarubd;
USE kalpatarubd;
-- --------------------------------------------------------

-- Estructura de tabla para la tabla `usuarios`

CREATE TABLE `usuarios` (
  `DNI` varchar(64) NOT NULL,
  `Nombre` varchar(64) NOT NULL,
  `Primer_Apellido` varchar(64),
  `Segundo_Apellido` varchar(64),
  `Correo` varchar(64) NOT NULL PRIMARY KEY,
  `Curso` varchar(128),
  `tokenCambiarPass` varchar(64),
  `administrador` int(1) not null default 0
);

-- Estructura de tabla para la tabla `deseos`

CREATE TABLE `deseos` (
   `id` int(9) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `texto` varchar(512) NOT NULL,
  `fecha_enviado` Date NOT NULL,
  `correo` varchar(64) NOT NULL,
  `idioma` int(1) NOT NULL,
  `validado` int NOT NULL DEFAULT 0,
  FOREIGN KEY(correo)REFERENCES usuarios(correo)ON DELETE CASCADE

);
-- Estructura de tabla para la tabla de valoraciones
CREATE TABLE `valoracion` (
  `correo` varchar(64) NOT NULL,
  `id` int(9) NOT NULL,
  PRIMARY KEY(`correo`,`id`),
  FOREIGN KEY(correo)REFERENCES usuarios(correo)ON DELETE CASCADE,	
  FOREIGN KEY(id)REFERENCES deseos(id)ON DELETE CASCADE
);

INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`, `Curso`,`administrador`) VALUES ('79172259A', 'Leo', 'Gil', 'Manjon', 'leonidades.sopelana@gmail.com', '2º Grado superior de Desarollo de Aplicaciones Web',1);
INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`, `Curso`) VALUES ('45949101T', 'Javier', 'Gonzalez', 'Landaluce', '20jgl99@gmail.com', '2º Grado superior de Desarollo de Aplicaciones Web');
INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`, `Curso`) VALUES ('78946666V', 'Javier', 'Pérez', 'Guisado', 'javipergui@gmail.com', '2º Grado superior de Desarollo de Aplicaciones Web');
INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`, `Curso`) VALUES ('16115107L', 'Jorge', 'Porras', 'Daviran', 'jordioni1705@gmail.com', '2º Grado superior de Desarollo de Aplicaciones Web');
INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`,`Curso`,`administrador`) VALUES ('20234424J', 'Endika', 'Andres', 'Martin','endika067@gmail.com','2º Grado superior de Administracion de Sistemas Informaticos en Red',1);
INSERT INTO `kalpatarubd`.`usuarios` (`DNI`, `Nombre`, `Primer_Apellido`, `Segundo_Apellido`, `Correo`,`administrador`) VALUES ('z', 'Ziortza', 'Ziortza', 'Ziortza', 'arboldelosdeseos25N@centrosanluis.com',1);

INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('que los medios de comunicación informen sobre violencia machista desde la responsabilidad y el compromiso. Las mujeres no mueren, se las asesina.','2021-10-16','jordioni1705@gmail.com',0,0);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('que no nos asesinen, que no nos violen, que no nos maten. Que dejemos de sentir miedo si vamos por la calle solas.','2021-10-16','leonidades.sopelana@gmail.com',0,1);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('un auténtico pacto de Estado ante la violencia de género. Un problema estructural y no una lacra.','2021-10-16','20jgl99@gmail.com',0,0);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('un pacto de mínimos dentro de los feminismos y que este pacto se base en la interseccionalidad. Las personas feministas no pensamos lo mismo sobre diversos temas.','2021-10-16','javipergui@gmail.com',0,1);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('seguir encontrando en la literatura, en la publicidad, en las series y en el cine mujeres luchadoras, poderosas y divertidas, como por ejemplo la intrépida Vaiana, la protagonista de la última película Disney','2021-10-16','javipergui@gmail.com',0,0);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('tener tiempo para nosotras. No tener que asumir el trabajo doméstico, ni la crianza, ni el cuidado de personas dependientes en su mayor parte. Ser y sentirnos libres. Divertirnos, reírnos y seguir teniendo fuerzas para luchar.','2021-10-16','javipergui@gmail.com',0,1);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('El problema de la mujer siempre ha sido un problema de hombres','2021-10-16','20jgl99@gmail.com',0,1);
INSERT INTO `kalpatarubd`.`deseos`(`texto`,`fecha_enviado`,`correo`,`idioma`,`validado`) VALUES ('Kaixo egun on denoi zer modos zaudete. Nik ondo eta zuk?. Nire ametsa athletic irabastea da.','2021-5-27','endika067@gmail.com',1,1);

INSERT INTO `kalpatarubd`.`valoracion`(`correo`,`id`) VALUES ('leonidades.sopelana@gmail.com',1);
INSERT INTO `kalpatarubd`.`valoracion`(`correo`,`id`) VALUES ('20jgl99@gmail.com',1);
INSERT INTO `kalpatarubd`.`valoracion`(`correo`,`id`) VALUES ('javipergui@gmail.com',1);
INSERT INTO `kalpatarubd`.`valoracion`(`correo`,`id`) VALUES ('jordioni1705@gmail.com',2);