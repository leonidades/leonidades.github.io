<main>
<div>
<h1>¿Quienes Somos?</h1>
<p>Somos un grupo de jovenes estudiantes del Centro San Luis, los cuales hemos realizado con este proyecto nuestro mayor esfuerzo y mejor intención para nuestro cliente. Esperamos cumplir con las espectativas tanto del cliente, como de aquellos usarios que usen la aplicación<./p>
</div>
<div>
<h1>¿Qué es el kalpataru?</h1>
<p>Es un árbol mitológico que tiene fama de cumplir cualquier deseo. Está mencionado en la literatura sánscrita como árbol divino, fuente de todos los deseos.</p>
<p>Según la literatura sánscrita, el Kalpavriksha nació durante el batido del océano de leche. Vino del océano con el kamadhenu, una vaca divina que proveería todas las necesidades. Indra, el rey de los dioses, guardó el árbol en su palacio.</p>
</div>
<div>
<h1>¿Cual es nuestra idea del kalpataru y el proyecto?</h1>
<p>El concepto que queremos plasmar, es que los alumnos que tienen deseos en contra de la violencia de genero puedan manifestarlos mediante un árbol virtual, y asi al igual que en la mitologia tengan la esperanza de que se cumpla.</p>
</div>
<div>
<h1>¿Por que realizamos este proyecto?</h1>
<p>La realización de este proyecto por parte nuestra, se debe a la nueva forma de enseñanza ETHAZI. Gracias a esta nueva dinamica nos vimos motivados a realizar este proyecto, propuesto por el profesorado</p>
</div>
<div>
<h1>¿Que es el ETHAZI?</h1>
<p>Consiste en la elaboración de un proyecto con situaciones problemáticas, en todos los casos, planteadas a una clase configurada en equipos, donde el proceso de trabajo ha de posibilitar al alumnado vivir la situación como un reto y, desde ahí, tiene que tener la oportunidad de generar el conocimiento necesario que le permita aportar las mejores soluciones.</p>
</div>
</main>