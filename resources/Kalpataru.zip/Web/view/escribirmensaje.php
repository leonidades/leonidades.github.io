<script src="./resources/js/EscribirMensaje.js"></script>
    <form action='./control/almacenarDeseo.php' method='POST' id="validarmensaje" class="submit">
        <div id="wrapper">

            <textarea id="field" placeholder="<?php echo $language['Escribe_un_deseo'] ?>" name="Deseo" rows="10" cols="50" maxlength="512" minlength="20" required onkeyup="countChar(this)" 
                style="overflow: hidden; word-wrap: break-word; resize: none; height: 160px;"></textarea>
            <div id='charNum'></div>

            <div class="radio">
            <input type="radio" name="idioma"  id="Castellano" value="0" checked><label for="Castellano">Castellano</label>
            <input type="radio" name="idioma"  id="Euskera" value="1"><label for="Euskera">Euskera</label>
            </div>
            <button type="submit"  id="boton" value="Enviar" onclick="validar(); return false;"><?php echo $language['Enviar'] ?></button>
    </form>
    <?php
    if (isset($_GET["resultado"])) {
        if ($_GET["resultado"]==0) {
            echo"<p";if ($color=="nocturno") {
                echo " style=\"color: #fff;\"";
              }else{
                echo " style=\"color: #000 ;\"";
              } echo">Para enviar un deseo debes inicia sesion</p> <p>(Recuerda que tienes que ser alumno del Centro San Luis)</p>";
        }else if ($_GET["resultado"]==1) {
            echo "<p";if ($color=="nocturno") {
                echo " style=\"color: #fff;\"";
              }else{
                echo " style=\"color: #000 ;\"";
              } echo">Mensaje enviado. Antes de visualizarlo en el arbol un administrador tendra que validarlo. Por favor ten paciencia</p>";
        }
    }
    ?>
        </div>