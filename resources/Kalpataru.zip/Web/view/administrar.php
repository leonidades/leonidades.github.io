<main>

<?php
$deseos=AccesoBD::getInstance()->mostrarTodosLosDeseosNoValidados();
for ($i=0; $i < count($deseos); $i++) { 
    echo"
    <div>
    <p> El alumno ".$deseos[$i]->usuario->nombre." ".$deseos[$i]->usuario->primer_apellido." ".$deseos[$i]->usuario->segundo_apellido." Ha escrito este mensaje en ";
    if($deseos[$i]->idioma==0){
        echo"Castellano";
    }else{
        echo"Euskera";
    }
    
    echo ":\" ".$deseos[$i]->texto."\"</p>
    <form action=\"./control/administrarDeseo.php\" method=\"get\">
    <input type=\"hidden\" name=\"id_deseo\" value=\"".$deseos[$i]->id."\">
    <input type=\"hidden\" name=\"decidir\" value=\"validar\">
    <input type=\"submit\" value=\"validar\">
    </form>
    <form action=\"./control/administrarDeseo.php\" method=\"get\">
    <input type=\"hidden\" name=\"id_deseo\" value=\"".$deseos[$i]->id."\">
    <input type=\"hidden\" name=\"decidir\" value=\"rechazar\">
    <input type=\"submit\" value=\"rechazar\">
    </form>
    </div>
    ";
}



?>
</main>