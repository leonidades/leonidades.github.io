<?php
// MENU INICIO
//header
$language['INICIO'] = 'Hasiera';
$language['escribir'] = 'Idatzi Mezua';
$language['idioma'] = 'Hizkuntza';
$language['iniciar_sesion'] = 'Hasi Saioa';
$language['Mi_perfil'] = 'Nire Profila';

//filtracion
$language['Curso'] = 'Ikastaro';
$language['idioma'] = 'Hizkuntza';
$language['Ordenar_por'] = 'Ordenatu';
$language['Filtrar'] = 'Filtratu';

//footer
$language['Página_desarrollada_por_el_grupo_JLJJ'] = 'JLJJ taldeak garatutako webgunea';
$language['quienes_somos'] = 'Nor Gara?';
$language['centro_sanluis'] = 'Centro Sanluis';
$language['Emakunde'] = 'Emakunde';

//ESCRIBIR MENSAJE
$language['Escribe_un_deseo'] = 'Idatzi amets bat';
$language['Castellano'] = 'Erdera';
$language['Euskera'] = 'Euskera';
$language['Enviar'] = 'Bidali';


//inicio Sesion
$language['iniciar_sesion'] = 'Hasi Saioa';
$language['Correo'] = 'Posta Elektronikoa';
$language['Escribe_tu_correo'] = 'Idatzi zure posta elektronikoa';
$language['Contraseña'] = 'Pasahitza';
$language['Escribe_tu_DNI'] = 'Idatzi zure DNI';
$language['iniciar_sesion'] = 'Hasi Saioa';

// Mi perfil
// Los datos
$language['Hola'] = 'Kaixo';
$language['estos_son_tus_datos'] = ',hauek dira zure datuak';
$language['nombre'] = 'Izen';
$language['apellido'] = 'Abizen';
$language['correo'] = 'Posta elektronikoa';
$language['pass'] = 'Pasahitza';
$language['Nueva_Contraseña'] = 'Pasahitz berria';
$language['guardar_cambios'] = 'Gorde aldaketak';

// menu lateral
$language['Mis_datos'] = 'Nire datuak';
$language['Mis_deseos'] = 'Nire Ametzak';
$language['Me_gusta'] = 'Gustokoak';

// quienes somos
$language['quienes_somos'] = '¿Nor gara?';
$language['quienes_somos_p'] = 'San Luis zentroko ikasle gazteen talde bat gara, eta proiektu honekin gure ahalegin eta asmo onena egin dugu gure bezeroarentzat. Bezeroaren eta aplikazioa erabiltzen duten erabiltzaileen itxaropenak betetzea espero dugu.';
$language['que_es_kalpataru'] = 'Zer da Kalpataru?';
$language['que_es_kalpataru_p'] = 'Edozein desio betetzeko ospea duen zuhaitz mitologiko bat da.
                                    Literatura sanskritoan zuhaitz jainkotiar gisa aipatzen da, desio guztien iturri gisa.
                                    Sanskritozko literaturaren arabera, Kalpavriksha esne-ozeanoa irabiatzean jaio zen.
                                    Ozeanoaren irteera kamadhenu izeneko behi batekin, behar guztiak beteko zituen behi jainkotiar batekin.
                                    Indrak, jainkoen erregeak, bere jauregian gorde zuen zuhaitza.';

// porque realizamos este proyecto
$language['Porque_proyecto'] = 'Zergatik egiten dugu proiektu hau?';
$language['Porque_proyecto_p'] = 'Proiektu hau guk egin dugu, ETHAZI irakaskuntza-modu berriari esker.
                                Dinamika berri horri esker, irakasleek proposatutako proiektu hau egiteko motibazioa izan genuen.';

// cual es nuestra idea
$language['Cual_idea'] = 'Zein da kalpataruaren eta proiektuaren gure ideia?';
$language['Cual_idea_p'] = 'Genero-indarkeriaren aurkako desioak dituzten ikasleek zuhaitz birtual baten bidez adierazi ahal izatea da erretratu nahi dugun kontzeptua, eta, horrela, mitologian bezala, hori betetzeko itxaropena izatea.';
$language['El_Ethazi'] = 'Zer da Ethazi?';
$language['El_Ethazi_p'] = 'Taldeka konfiguratutako klase bati planteatutako egoera problematikoak dituen proiektu bat egitean datza.
                            Lan-prozesuak egoera erronka gisa bizitzeko aukera eman behar die ikasleei, eta, hortik abiatuta, 
                            irtenbiderik onenak eman ahal izateko beharrezkoa den ezagutza sortzeko aukera izan behar du.';

?>