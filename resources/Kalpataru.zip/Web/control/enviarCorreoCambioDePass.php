<?php
require_once "../model/AccesoBD.class.php";
session_start();
$usuario=unserialize($_SESSION["usuario"]);
$pass=$_POST["pass"];
$token=md5(uniqid(rand(),true));
AccesoBD::getInstance()->NuevoTokenCambioDePass($token,$usuario);
// 
require_once "../resources/libreria/PHPMailer.php";
require_once "../resources/libreria/SMTP.php";
require_once "../resources/libreria/Exception.php";
require_once "../resources/libreria/POP3.php";
require_once "../resources/libreria/OAuth.php";

$email = new PHPMailer\PHPMailer\PHPMailer();

$email->isSMTP();
$email->SMTPDebug=1;
$email->SMTPAuth =true;
$email->SMTPSecure='ssl';
$email->Host='smtp.gmail.com';
$email->Port='465';

//necesitamos un correo para la web
$email->Username='2daw1021@gmail.com';
$email->Password='segundodaw';
$email->From='2daw1021@gmail.com';
$email->FromName='KalpataruWEB';
$email->AddAddress("$usuario->correo");

//por si queremos ver todos los correos que se mandan
$email->AddReplyTo('2daw1021@gmail.com');
$email->isHTML(true);
$email->Subject="Cambio de contraseña de la web kalpataru";
$email->Body="<h2>Cambia la contraseña </h2>
<form action=\"http://localhost/kalpataru/control/cambiarPass.php\" method=\"POST\">
<input type=\"hidden\" name=\"token\" value=\"$token\">
<input type=\"hidden\" name=\"pass\" value=\"$pass\">
<input type=\"hidden\" name=\"correo\" value=\"$usuario->correo\">
<input type=\"submit\" value=\"Cambiar la contraseña\">
</form>";
$email->AltBody="Para ver este mensaje, debes utilizar un gestor de correo compatible con HTML";
if ($email->Send()) {
    echo "mensaje enviado";
    header('Location: ../index.php?view=miperfil&resultado=1');
}else{
    echo "mensaje no enviado".$email->ErrorInfo;
    header('Location: ../index.php?view=miperfil&resultado=1');

}
?>
