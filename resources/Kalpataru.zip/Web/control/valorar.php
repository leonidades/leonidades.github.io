<?php
require_once "../model/AccesoBD.class.php";
session_start();
if (isset($_SESSION["usuario"])) {
    $usuario=$_SESSION["usuario"];
}else{

}
$id_deseo=$_POST["id_deseo"];

if (isset($usuario)) {
    if (!AccesoBD::getInstance()->comprobrobarValoracionDeseo(unserialize($usuario),$id_deseo)) {
         $sql=AccesoBD::getInstance()->valorarDeseo(unserialize($usuario),$id_deseo);
         header("Location: /kalpataru/index.php?view=inicio");
    }else{
        AccesoBD::getInstance()->CancelarValorarDeseo(unserialize($usuario),$id_deseo);
        header("Location: /kalpataru/index.php?view=inicio");
    }

}else{
    header("Location: /kalpataru/index.php?view=inicio&error=1");
}
?>