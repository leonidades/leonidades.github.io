<?php

class Usuario{
    public $dni, $correo, $nombre, $primer_apellido,$segundo_apellido, $curso, $administrador;

    function __construct($dni, $correo, $nombre, $primer_apellido,$segundo_apellido, $curso, $administrador){
      $this->dni=$dni;
      $this->correo=$correo;
      $this->nombre=$nombre;
      $this->primer_apellido=$primer_apellido;
      $this->segundo_apellido=$segundo_apellido;
      $this->curso=$curso;
      $this->administrador=$administrador;
    }

    function __toString(){

        return "$this->nombre";
    }

    
}
?>