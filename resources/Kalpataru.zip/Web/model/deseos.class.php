<?php
class Deseo{
    public $id, $texto, $fecha_enviado, $idioma, $usuario, $valoraciones;

    function __construct($id, $texto, $fecha_enviado, $idioma, $usuario, $valoraciones){
      $this->id=$id;
      $this->texto=$texto;
      $this->fecha_enviado=$fecha_enviado;
      $this->idioma=$idioma;
      $this->usuario=$usuario;
      $this->valoraciones=$valoraciones;
    }

    function __toString(){

        return "$this->texto";
    }
}
?>