<?php
require_once "../model/AccesoBD.class.php"; 
require_once "../resources/libreria/PHPMailer.php";
require_once "../resources/libreria/SMTP.php";
require_once "../resources/libreria/Exception.php";
require_once "../resources/libreria/POP3.php";
require_once "../resources/libreria/OAuth.php";

$id_deseo=$_GET["id_deseo"];
$deseo=AccesoBD::getInstance()->CapturarDeseoConcreto($id_deseo);

$email = new PHPMailer\PHPMailer\PHPMailer();

$email->isSMTP();
$email->SMTPDebug=1;
$email->SMTPAuth =true;
$email->SMTPSecure='ssl';
$email->Host='smtp.gmail.com';
$email->Port='465';

$email->Username='kalpatarudaw@gmail.com';
$email->Password='kalpatarujljj';

$email->From='kalpatarudaw@gmail.com';
$email->FromName='KalpataruWEB';

//a quien le llega
$email->AddAddress("leonidades.sopelana@gmail.com");
// $email->AddAddress("arboldelosdeseos25N@centrosanluis.com");

//por si queremos ver todos los correos que se mandan
$email->AddReplyTo('kalpatarudaw@gmail.com');
$email->isHTML(true);
$email->Subject="Validar deseos de la web kalpataru";
$email->Body="<div>
<p> El alumno ".$deseo->usuario->nombre." ".$deseo->usuario->primer_apellido." ".$deseo->usuario->segundo_apellido." Ha escrito este mensaje en ";
if($deseo->idioma==0){
    echo"Castellano";
}else{
    echo"Euskera";
}

echo":\"$deseo->texto\"</p>
<form action=\"localhost/kalptaru/control/administrarDeseo.php\" method=\"get\">
<input type=\"hidden\" name=\"id_deseo\" value=\"".$deseo->id."\">
<input type=\"hidden\" name=\"decidir\" value=\"validar\">
<input type=\"submit\" value=\"validar\">
</form>
<form action=\"localhost/kalptaru/control/administrarDeseo.php\" method=\"get\">
<input type=\"hidden\" name=\"id_deseo\" value=\"".$deseo->id."\">
<input type=\"hidden\" name=\"decidir\" value=\"rechazar\">
<input type=\"submit\" value=\"rechazar\">
</form>
</div>";


$email->AltBody="Para ver este mensaje, debes utilizar un gestor de correo compatible con HTML";
if ($email->Send()) {
    echo "mensaje enviado";
    header('Location: ../index.php?view=escribirmensaje&resultado=1');
}else{
    echo "mensaje no enviado".$email->ErrorInfo;
}


?>