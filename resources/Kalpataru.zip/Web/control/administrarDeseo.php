<?php
require_once "../model/AccesoBD.class.php";
$id_deseo=$_GET["id_deseo"];
$decidir=$_GET["decidir"];

if ($decidir=="validar") {
    AccesoBD::getInstance()->ValidarDeseo($id_deseo);
    header('Location: /kalpataru/index.php?view=administrar');
}else if($decidir=="rechazar"){
    AccesoBD::getInstance()->RechazarDeseo($id_deseo);
    header('Location: /kalpataru/index.php?view=administrar');
}
?>