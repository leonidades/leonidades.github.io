    <?php
      session_start();
    require "./model/AccesoBD.class.php";
  $usuario=null;
require_once "./control/set_idioma.php";
require_once "./control/mantenerEstilos.php";
if (isset($_SESSION['usuario'])) {
   $usuario=unserialize($_SESSION['usuario']);
}
$view="inicio";
if (isset($_GET["view"])) {
 $view=$_GET["view"];
 }
 $color="nocturno";
 if (isset($_SESSION["color"])) {
  $color=$_SESSION["color"];
}
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Kalpataru tree</title>
    <!-- <meta http-equiv="refresh" content="5"> -->
    <link rel="stylesheet" href="resources/css/style.css">
    <link rel="icon" href="resources/img/hoja.ico" >
    <?php
          echo "<link rel=\"stylesheet\" href=\"resources/css/".$view.".css\">";
    ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Nunito+Sans:wght@200&display=swap" rel="stylesheet">
    <script src='./resources/libreria/jquery-3.6.0.min.js'></script>
    <script src="./resources/js/ModoDiurno.js"></script>
	<script src="./resources/js/Hojas.js"></script>
  <script src="./resources/js/FiltroChiquito.js"></script>
  </head>
  <body <?php if ($color=="nocturno") {
    echo "style=\"background-color: #1f1f23;\"";
  }else{
    echo "style=\"background-color: #E5DDE6;\"";
  } ?>>
    <header>
      <img id="CSL" src="resources/img/CentroSanLuis.png" alt="Logo San Luis">
        <nav>
          <ul>
            <li>
              <a href="index.php?view=inicio"><?php echo $language['INICIO'] ?></a>
            </li>
            <li>
              <a href="index.php?view=escribirmensaje"><?php echo $language['escribir'] ?></a>
            </li>

          <?php
          if($_SESSION['lang']=="eu"){
           echo "<li><a href=\"index.php?lang=es&view=$view\">Hizkuntza</a></li>";
          }else{
            echo"<li><a href=\"index.php?lang=eu&view=$view\">Idioma</a></li>";
          }
          ?>

          <?php

          if(isset($usuario)){
            echo "<li id=\"borde\"><a href=\"index.php?view=miperfil\">".$language['Mi_perfil']."</a></li>";
          }else{
            echo "<li id=\"borde\"><a href=\"index.php?view=iniciarsesion\">".$language['iniciar_sesion']."</a></li>";
          }
          ?>

          </ul>
        </nav>
      <img id="EMA" src="resources/img/emakunde.png" alt="Logo Emakunde">
    <form action="./control/" method="get">
	  <label class="switch">
      <input id="check" onchange='handleChange(this);' type="checkbox"  <?php if ($color=="nocturno") {
        echo"checked";
      }?>>
      <span class="slider round"></span>
    </label>
    </form>
    </header>
<?php

    include "./view/$view.php";
        ?>
    <footer>
      <p><?php echo $language['Página_desarrollada_por_el_grupo_JLJJ'] ?></p>
      <?php
      if (isset($usuario)) {
        if ($usuario->administrador==1) {
          echo "<a href=\"index.php?view=administrar\"> ERES ADMINISTRADOR!!!</a>";
        }
      }
         
      ?>
      
      <p id="enlaces">
        <a href="index.php?view=quienesSomos"><?php echo $language['quienes_somos'] ?></a>
        <a href="https://www.centrosanluis.com/"><?php echo $language['centro_sanluis'] ?></a>
        <a href="https://www.emakunde.euskadi.eus/inicio/"><?php echo $language['Emakunde'] ?></a>
    </p>
    </footer>
  </div>
  </body>
</html>

<script type="text/javascript">

</script>
