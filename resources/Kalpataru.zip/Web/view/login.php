<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title> Login </title>
    <link href="../resources/css/login.css" rel="stylesheet" type="text/css">
</head>

<body>
    <main>
        <section id="principal">
            <div id="titulo">
                <h1> Inicio <span class="color">Sesion</span> </h1>
            </div>
            <form class="login-estilos" action="../control/iniciarsesion.php" method="POST">
                <label id="nombre">
                    <span>Correo</span><input type="mail" name="correo" placeholder="Escribe tu E-mail" required="true" />
                </label>
                <label id="passwd">
                    <span>Contraseña</span><input type="password" name="pwd" placeholder="Escribe tu DNI" required="true" />
                </label>
                    <input type="submit" class="btn" value="Iniciar sesion">
                </div>
            </form>
        </section>
    </main>
</body>

</html>
