    // for (var i = 1; i < 50; i++) {
    //     (function () {
         
    //         document.getElementById("hoja"+i).addEventListener("click", function() {
    //             for(var j=1;j<50;j++){
    //             document.getElementById("deseo"+j).style.display = "none";
                
    //             }
    //             alert("hola");
    //             $("form:eq("+i+1+")").css("display","block");
    //             document.getElementById("deseo"+i).style.display = "block";

    //          });
    //     }); 
    // }
    function ejecutar(i){
        for(var j=1;j<50;j++){
            if (document.getElementById("deseo"+j)!=null) {
                document.getElementById("deseo"+j).style.display = "none";
            } 
            }
            let e=i+1;
            $("form:eq("+e+")").css("display","block");
    }