<?php
require_once "../model/AccesoBD.class.php";
$idioma=$_POST["idioma"];
$texto=$_POST["Deseo"];
session_start();

if (isset($_SESSION["usuario"])) {
    $id_deseo=AccesoBD::getInstance()->CrearDeseo($texto,unserialize($_SESSION["usuario"]),$idioma);

    header("Location: ./enviarCorreoClienta.php?id_deseo=\"$id_deseo\"");
}else{
header('Location: ../index.php?view=escribirmensaje&resultado=0');
}
?>