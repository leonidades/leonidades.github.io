<?php
// MENU INICIO
// Header
$language['INICIO'] = 'Inicio';
$language['escribir'] = 'Escribir Deseo';
$language['idioma'] = 'Idioma';
$language['iniciar_sesion'] = 'Iniciar Sesion';
$language['Mi_perfil'] = 'Mi perfil';

//filtracion
$language['Curso'] = 'Curso';
$language['idioma'] = 'idioma';
$language['Ordenar_por'] = 'Ordenar por';
$language['Filtrar'] = 'Filtrar';

// Footer
$language['Página_desarrollada_por_el_grupo_JLJJ'] = 'Página desarrollada por el grupo JLJJ';
$language['quienes_somos'] = 'Quienes somos?';
$language['centro_sanluis'] = 'Centro Sanluis';
$language['Emakunde'] = 'Emakunde';

//ESCRIBIR MENSAJE
$language['Escribe_un_deseo'] = 'Escribe un deseo';
$language['Castellano'] = 'Castellano';
$language['Euskera'] = 'Euskera';
$language['Enviar'] = 'Enviar';

//inicio Sesion
$language['iniciar_sesion'] = 'iniciar sesion';
$language['Correo'] = 'Correo';
$language['Escribe_tu_correo'] = 'Escribe tu correo';
$language['Contraseña'] = 'Contraseña';
$language['Escribe_tu_DNI'] = 'Escribe tu DNI';
$language['iniciar_sesion'] = 'iniciar sesion';

// Mi perfil
// Los datos
$language['Hola'] = 'Hola';
$language['estos_son_tus_datos'] = ',estos son tus datos';
$language['nombre'] = 'Nombre';
$language['apellido'] = 'Apellido';
$language['correo'] = 'Correo';
$language['pass'] = 'Contraseña';
$language['Nueva_Contraseña'] = 'Nueva Contraseña';
$language['guardar_cambios'] = 'Guardar cambios';

// Menu lateral
$language['Mis_datos'] = 'Mis datos';
$language['Mis_deseos'] = 'Mis deseos';
$language['Me_gusta'] = 'Me gusta';

// quienes somos
$language['quienes_somos'] = '¿Quienes somos?';
$language['quienes_somos_p'] = 'Somos un grupo de jovenes estudiantes del Centro San Luis, los cuales hemos realizado con este proyecto nuestro mayor esfuerzo y mejor intención para nuestro cliente. Esperamos cumplir con las espectativas tanto del cliente, como de aquellos usarios que usen la aplicación?';
$language['que_es_kalpataru'] = '¿Que es el Kalpataru?';
$language['que_es_kalpataru_p'] = 'Es un árbol mitológico que tiene fama de cumplir cualquier deseo. 
                                    Está mencionado en la literatura sánscrita como árbol divino, fuente de todos los deseos.
                                    Según la literatura sánscrita, el Kalpavriksha nació durante el batido del océano de leche. 
                                    Vino del océano con el kamadhenu, una vaca divina que proveería todas las necesidades. 
                                    Indra, el rey de los dioses, guardó el árbol en su palacio.';
// cual es nuestra idea
$language['Cual_idea'] = '¿Cual es nuestra idea del kalpataru y el proyecto?';
$language['Cual_idea_p'] = 'El concepto que queremos plasmar, es que los alumnos que tienen deseos en contra de la violencia de genero puedan manifestarlos mediante un árbol virtual, y asi al igual que en la mitologia tengan la esperanza de que se cumpla.';

// porque realizamos este proyecto
$language['Porque_proyecto'] = '¿Por que realizamos este proyecto?';
$language['Porque_proyecto_p'] = 'La realización de este proyecto por parte nuestra, se debe a la nueva forma de enseñanza ETHAZI. 
                                Gracias a esta nueva dinamica nos vimos motivados a realizar este proyecto, propuesto por el profesorado';

// que es el ethazi
$language['El_Ethazi'] = '¿Que es el ETHAZI?';
$language['El_Ethazi_p'] = 'Consiste en la elaboración de un proyecto con situaciones problemáticas, en todos los casos, planteadas a una clase configurada en equipos, 
                            donde el proceso de trabajo ha de posibilitar al alumnado vivir la situación como un reto y, desde ahí,
                             tiene que tener la oportunidad de generar el conocimiento necesario que le permita aportar las mejores soluciones.';


?>