


    $(document).ready(function(){
    $("#Datos").click(function (){


    $("#MisDatos").css('display','block');
    if($("a:contains('Mis Datos')")){
    $("#MisDeseos").css('display','none');
    $("#MeGusta").css('display','none');
            }
        });
    

        $("#Deseos").click(function (){
        $("#MisDeseos").css('display','block');
        if("a:contains('Mis Deseos')"){
        $("#MisDatos").css('display','none');
        $("#MeGusta").css('display','none');
            }
        });
    
        $("#like").click(function (){
        $('#MeGusta').css('display','block');
        if("a:contains('Me gusta')"){
        $("#MisDeseos").css('display','none');
        $("#MisDatos").css('display','none');
            }
        });
    });

    


