<?php
if(isset($_GET['color'])){
if ($_GET['color']=="nocturno") {
    $_SESSION["color"]="nocturno";
}else{
    $_SESSION["color"]="dia";
}
}
?>