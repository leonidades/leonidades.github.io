<?php
 $deseos=array();

 $orden="random";
 if (isset($_GET["orden"])) {
  $orden=$_GET["orden"];
 }
 $curso="all";
 if (isset($_GET["curso"])) {
  $curso=$_GET["curso"];
 }
 $idioma="all";
 if (isset($_GET["idioma"])) {
  $idioma=$_GET["idioma"];
 }

 $deseos=AccesoBD::getInstance()->mostrarDeseos($orden, $curso, $idioma);
?>
<!-- <div class="flex-wrapper"> -->
  <div class="mid">
<!--Aqui iria el arbol principal con cada uno de los deseos-->
    <section>
        <div id="arbol">
          <img src="resources/img/kalpataru.PNG" alt="Arbol Kalpataru" >
        </div>
        <?php
        for ($i=0; $i < count($deseos) ; $i++) {
          $e=$i+1;
          echo"
          <div id=\"hoja".$e."\" >
          <img src=\"resources/img/hoja.gif\" alt=\"hoja\" onclick=\"ejecutar($e);\"> 
          <input type=\"hidden\" value=\"".$deseos[$i]->id."\">
          </div>
          ";
        }
        ?>
    </section>
<!--En este apartado se presentan muestran los deseos. Todo esto es provisional-->
    <aside class="deseos">
    <?php
    if (isset($_GET["error"])) { 
    if ($_GET["error"]==1) {
    echo"<p";
    if ($color=="nocturno") {
      echo " style=\"color: #fff;\"";
    }else{
      echo " style=\"color: #000 ;\"";
    }
    echo">Para valorar deseos tienes que iniciar sesion</p>";
    }
  }
    ?>
    
      <form action="index.php" method="GET">
        <div id="filtro">
         <label for="curso" <?php if ($color=="nocturno") {
    echo "style=\"color: #fff;\"";
  }else{
    echo "style=\"color: #000 ;\"";
  } ?>>Curso:</label>
         <select name="curso" id="curso">
           <option value="all" selected >todos los cursos</option>
           <option value="1º Bachillerato Cientifico-Tecnologico">1º Bachillerato Cientifico-Tecnologico</option>
           <option value="2º Bachillerato Cientifico-Tecnologico">2º Bachillerato Cientifico-Tecnologico</option>
           <option value="1º Bachillerato de Ciencias Sociales">1º Bachillerato de Ciencias Sociales</option>
           <option value="2º Bachillerato de Ciencias Sociales">2º Bachillerato de Ciencias Sociales</option>
           <option value="1º Formacion de  Servicios Administrativos">1º Formacion de  Servicios Administrativos</option>
           <option value="2º Formacion de Servicios Administrativos">2º Formacion de Servicios Administrativos</option>
           <option value="1º Grado medio de Sistemas Microinformaticos y Redes">1º Grado medio de Sistemas Microinformaticos y Redes</option>
           <option value="2º Grado medio de Sistemas Microinformaticos y Redes">2º Grado medio de Sistemas Microinformaticos y Redes</option>
           <option value="1º Grado medio de Gestion Administrativa">1º Grado medio de Gestion Administrativa</option>
           <option value="2º Grado medio de Gestion Administrativa">2º Grado medio de Gestion Administrativa</option>
           <option value="1º Grado medio de Actividades Comerciales">1º Grado medio de Actividades Comerciales</option>
           <option value="2º Grado medio de Actividades Comerciales">2º Grado medio de Actividades Comerciales</option>
           <option value="1º Grado superior de Administracion de Sistemas Informaticos en Red">1º Grado superior de Administracion de Sistemas Informaticos en Red</option>
           <option value="2º Grado superior de Administracion de Sistemas Informaticos en Red">2º Grado superior de Administracion de Sistemas Informaticos en Red</option>
           <option value="1º Grado superior de Desarollo de Aplicaciones Web">1º Grado superior de Desarollo de Aplicaciones Web</option>
           <option value="2º Grado superior de Desarollo de Aplicaciones Web">2º Grado superior de Desarollo de Aplicaciones Web</option>
           <option value="1º Grado Superior de  Administración y Finanzas es">1º Grado Superior de  Administración y Finanzas es</option>
           <option value="2º Grado Superior de Administracion y Finanzas es">2º Grado Superior de Administracion y Finanzas es</option>
           <option value="1º Grado Superior de Administracion y Finanzas eu">2º Grado Superior de Administracion y Finanzas eu</option>
           <option value="2º Grado Superior de Administracion y Finanzas eu">2º Grado Superior de Administracion y Finanzas eu</option>
           <option value="1º Grado Superior de Marketing y Publicidad">1º Grado Superior de Marketing y Publicidad</option>
           <option value="2º Grado Superior de Marketing y Publicidad">2º Grado Superior de Marketing y Publicidad</option>
           <option value="1º Grado Superior de Integración Social">1º Grado Superior de Integración Social</option>
           <option value="2º Grado Superior de Integración Social">2º Grado Superior de Integración Social</option>
         </select>

         <br><br>

         <label for="idioma" <?php if ($color=="nocturno") {
    echo "style=\"color: #fff;\"";
  }else{
    echo "style=\"color: #000 ;\"";
  } ?>>Idioma:</label>
         <select name="idioma" id="idioma">
           <option value="all" selected>Castellano y Euskera</option>
           <option value="castellano">Castellano</option>
           <option value="euskera">Euskera</option>
         </select>

         <br><br>

         <label for="orden" <?php if ($color=="nocturno") {
    echo "style=\"color: #fff;\"";
  }else{
    echo "style=\"color: #000 ;\"";
  } ?>>Ordenar por:</label>
         <select name="orden" id="orden">
           <option value="random" selected >Aleatorio</option>
           <option value="recientes">Mas recientes</option>
           <option value="antiguos">Mas antiguos</option>
           <option value="valorados">Mas valorado</option>
         </select>

         <br><br>

         <input type="submit" value="Filtrar">
       </div>
     </form>
     <div id="btnFiltroPequeño"><a onclick="MostrarFiltro();">Filtro</a></div>
    <?php

    for ($i=0; $i < count($deseos) ; $i++) {
      $e=$i+1;
      echo "
      <form action=\"./control/valorar.php\" method=\"post\" id=\"deseo".$e."\" class=\"deseo\">
      <input type=\"hidden\" value=\"".$deseos[$i]->id."\" name=\"id_deseo\" id=\"".$deseos[$i]->id."\">
      <div id=\"txtdeseo\">
        <p>".$deseos[$i]->texto."</p>

         <div class=\"cajamg\">";
         if (isset($usuario)) {
          if (AccesoBD::getInstance()->comprobrobarValoracionDeseo($usuario,$deseos[$i]->id)) {
            echo"<button type=\"submit\" class=\"mglleno\"> </button>";
          }else{
            echo"<button type=\"submit\" class=\"mg\"> </button>";
          }
         }else{
          echo"<button type=\"submit\" class=\"mg\"> </button>";
         }
          echo"
          </div>

          <div id=\"megusta\">".$deseos[$i]->valoraciones." LIKES </div>
      </div>
      </form>";
    }
    ?>
    </aside>
</div>