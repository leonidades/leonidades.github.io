function handleChange(checkbox) {
    if(checkbox.checked == true){
        window.location.href="index.php?color=nocturno";
    }else{
        window.location.href="index.php?color=dia";
   }
}
